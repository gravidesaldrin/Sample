class StaticPagesController < ApplicationController
  def home
  end

  def about
  end

  def contat_us
  end

  def help
  end
end
